result = -c[1]/(pow(c[0], 2) + pow(c[1], 2));
